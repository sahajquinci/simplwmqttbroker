namespace sahajquinci.MQTT_Broker.Messages;
        // class declarations
         class MqttMsgBase;
         class MqttMsgPubrec;
         class MqttMsgConnack;
         class MqttMsgState;
         class MqttMsgConnect;
         class MqttMsgUnsubscribe;
         class MqttMsgDisconnect;
         class MqttMsgPubcomp;
         class MqttMsgPuback;
         class MqttMsgPubrel;
         class MqttMsgUnsuback;
         class MqttMsgPingReq;
         class MqttMsgSubscribe;
         class MqttMsgContext;
         class MqttMsgSuback;
         class MqttMsgPingResp;
         class MqttMsgPublish;
     class MqttMsgBase 
    {
        // class delegates

        // class events

        // class functions
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        INTEGER MessageId;
    };

     class MqttMsgPubrec 
    {
        // class delegates

        // class events

        // class functions
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        INTEGER __class_id__;

        // class properties
        INTEGER MessageId;
    };

     class MqttMsgConnack 
    {
        // class delegates

        // class events

        // class functions
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        INTEGER __class_id__;

        // class properties
        INTEGER MessageId;
    };

    static class MqttMsgState // enum
    {
        static SIGNED_LONG_INTEGER QueuedQos0;
        static SIGNED_LONG_INTEGER QueuedQos1;
        static SIGNED_LONG_INTEGER QueuedQos2;
        static SIGNED_LONG_INTEGER WaitForPuback;
        static SIGNED_LONG_INTEGER WaitForPubrec;
        static SIGNED_LONG_INTEGER WaitForPubrel;
        static SIGNED_LONG_INTEGER WaitForPubcomp;
        static SIGNED_LONG_INTEGER SendPubrec;
        static SIGNED_LONG_INTEGER SendPubrel;
        static SIGNED_LONG_INTEGER SendPubcomp;
        static SIGNED_LONG_INTEGER SendPuback;
        static SIGNED_LONG_INTEGER SendSubscribe;
        static SIGNED_LONG_INTEGER SendUnsubscribe;
        static SIGNED_LONG_INTEGER WaitForSuback;
        static SIGNED_LONG_INTEGER WaitForUnsuback;
    };

     class MqttMsgConnect 
    {
        // class delegates

        // class events

        // class functions
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        INTEGER __class_id__;

        // class properties
        STRING ProtocolName[];
        STRING ClientId[];
        STRING WillTopic[];
        STRING WillMessage[];
        STRING Username[];
        STRING Password[];
        INTEGER KeepAlivePeriod;
        INTEGER MessageId;
    };

     class MqttMsgUnsubscribe 
    {
        // class delegates

        // class events

        // class functions
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        INTEGER __class_id__;

        // class properties
        STRING Topics[][];
        INTEGER MessageId;
    };

     class MqttMsgDisconnect 
    {
        // class delegates

        // class events

        // class functions
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        INTEGER __class_id__;

        // class properties
        INTEGER MessageId;
    };

     class MqttMsgPubcomp 
    {
        // class delegates

        // class events

        // class functions
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        INTEGER __class_id__;

        // class properties
        INTEGER MessageId;
    };

     class MqttMsgPuback 
    {
        // class delegates

        // class events

        // class functions
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        INTEGER __class_id__;

        // class properties
        INTEGER MessageId;
    };

     class MqttMsgPubrel 
    {
        // class delegates

        // class events

        // class functions
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        INTEGER __class_id__;

        // class properties
        INTEGER MessageId;
    };

     class MqttMsgUnsuback 
    {
        // class delegates

        // class events

        // class functions
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        INTEGER __class_id__;

        // class properties
        INTEGER MessageId;
    };

     class MqttMsgPingReq 
    {
        // class delegates

        // class events

        // class functions
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        INTEGER __class_id__;

        // class properties
        INTEGER MessageId;
    };

     class MqttMsgSubscribe 
    {
        // class delegates

        // class events

        // class functions
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        INTEGER __class_id__;

        // class properties
        STRING Topics[][];
        INTEGER MessageId;
    };

     class MqttMsgContext 
    {
        // class delegates

        // class events

        // class functions
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        MqttMsgBase Message;
        MqttMsgState State;
        SIGNED_LONG_INTEGER Attempt;
        INTEGER Key;
    };

     class MqttMsgSuback 
    {
        // class delegates

        // class events

        // class functions
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        INTEGER __class_id__;

        // class properties
        INTEGER MessageId;
    };

     class MqttMsgPingResp 
    {
        // class delegates

        // class events

        // class functions
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        INTEGER __class_id__;

        // class properties
        INTEGER MessageId;
    };

     class MqttMsgPublish 
    {
        // class delegates

        // class events

        // class functions
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        INTEGER __class_id__;

        // class properties
        STRING Topic[];
        INTEGER MessageId;
    };

namespace sahajquinci.MQTT_Broker.Managers;
        // class declarations
         class MqttSubscriptionComparer;
         class MqttSubscriptionComparerType;
         class Subscription;
         class SessionManager;
         class PublishManager;
         class SubscriptionManager;
         class Session;
         class PacketManager;
           class PacketReadyToBeSentEventHandler;
           class ClientSubscribedEventHandler;
    static class MqttSubscriptionComparerType // enum
    {
        static SIGNED_LONG_INTEGER OnClientId;
        static SIGNED_LONG_INTEGER OnTopic;
    };

     class Subscription 
    {
        // class delegates

        // class events

        // class functions
        FUNCTION Dispose ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        STRING ClientId[];
        STRING Topic[];
    };

     class SubscriptionManager 
    {
        // class delegates

        // class events
        EventHandler ClientSubscribed ( SubscriptionManager sender, ClientSubscribedEventHandler e );

        // class functions
        FUNCTION Subscribe ( STRING clientId , MqttMsgSubscribe packet );
        FUNCTION Unsubscribe ( STRING clientId , MqttMsgUnsubscribe packet );
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
    };

namespace sahajquinci.MQTT_Broker.Exceptions;
        // class declarations
         class MqttCommunicationException;
         class MqttTimeoutException;
         class MqttClientException;
         class MqttClientErrorCode;
         class MqttConnectionException;
     class MqttCommunicationException 
    {
        // class delegates

        // class events

        // class functions
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        INTEGER __class_id__;

        // class properties
        STRING Message[];
        STRING StackTrace[];
        STRING HelpLink[];
        STRING Source[];
        SIGNED_LONG_INTEGER HResult;
    };

     class MqttTimeoutException 
    {
        // class delegates

        // class events

        // class functions
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        INTEGER __class_id__;

        // class properties
        STRING Message[];
        STRING StackTrace[];
        STRING HelpLink[];
        STRING Source[];
        SIGNED_LONG_INTEGER HResult;
    };

    static class MqttClientErrorCode // enum
    {
        static SIGNED_LONG_INTEGER WillWrong;
        static SIGNED_LONG_INTEGER KeepAliveWrong;
        static SIGNED_LONG_INTEGER TopicWildcard;
        static SIGNED_LONG_INTEGER TopicLength;
        static SIGNED_LONG_INTEGER QosNotAllowed;
        static SIGNED_LONG_INTEGER TopicsEmpty;
        static SIGNED_LONG_INTEGER QosLevelsEmpty;
        static SIGNED_LONG_INTEGER TopicsQosLevelsNotMatch;
        static SIGNED_LONG_INTEGER WrongBrokerMessage;
        static SIGNED_LONG_INTEGER WrongMessageId;
        static SIGNED_LONG_INTEGER InflightQueueFull;
        static SIGNED_LONG_INTEGER InvalidFlagBits;
        static SIGNED_LONG_INTEGER InvalidConnectFlags;
        static SIGNED_LONG_INTEGER InvalidClientId;
        static SIGNED_LONG_INTEGER InvalidProtocolName;
    };

namespace sahajquinci.MQTT_Broker.Events;
        // class declarations
         class PacketReceivedEventHandler;
         class PacketReadyToBeSentEventHandler;

namespace sahajquinci.MqttBroker;
        // class declarations
         class MqttBrokerStart;
     class MqttBrokerStart 
    {
        // class delegates

        // class events

        // class functions
        FUNCTION InitializeBis ( STRING username , STRING password , LONG_INTEGER controlSytemAuthentication , LONG_INTEGER port , LONG_INTEGER ssl , STRING certificateFileName , STRING privateKeyFileName , LONG_INTEGER enableWebSocketServer , LONG_INTEGER webSocketServerPort );
        FUNCTION SetLogLevel ( LONG_INTEGER logLevel );
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
    };

namespace sahajquinci.MQTT_Broker.Utility;
        // class declarations
         class PacketDecoder;
         class MsgBuilder;
    static class PacketDecoder 
    {
        // class delegates

        // class events

        // class functions
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
    };

    static class MsgBuilder 
    {
        // class delegates

        // class events

        // class functions
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
    };

namespace sahajquinci.MQTT_Broker;
        // class declarations
         class ServerBase;
         class TCPServer;
         class MqttSettings;
         class MqttClient;
         class WSServer;
         class ClientSubscribedEventHandler;
     class MqttSettings 
    {
        // class delegates

        // class events

        // class functions
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        static SIGNED_LONG_INTEGER MQTT_BROKER_DEFAULT_PORT;
        static SIGNED_LONG_INTEGER MQTT_BROKER_DEFAULT_SSL_PORT;
        static SIGNED_LONG_INTEGER MQTT_DEFAULT_TIMEOUT;
        static SIGNED_LONG_INTEGER MQTT_ATTEMPTS_RETRY;
        static SIGNED_LONG_INTEGER MQTT_DELAY_RETRY;
        static SIGNED_LONG_INTEGER MQTT_CONNECT_TIMEOUT;
        static SIGNED_LONG_INTEGER MQTT_MAX_INFLIGHT_QUEUE_SIZE;
        static SIGNED_LONG_INTEGER NUMBER_OF_CONNECTIONS;
        static SIGNED_LONG_INTEGER WEB_CLIENT_BUFFER_SIZE;

        // class properties
        SIGNED_LONG_INTEGER Port;
        SIGNED_LONG_INTEGER WsPort;
        SIGNED_LONG_INTEGER SslPort;
        SIGNED_LONG_INTEGER TimeoutOnConnection;
        SIGNED_LONG_INTEGER TimeoutOnReceiving;
        SIGNED_LONG_INTEGER AttemptsOnRetry;
        SIGNED_LONG_INTEGER DelayOnRetry;
        SIGNED_LONG_INTEGER InflightQueueSize;
        SIGNED_LONG_INTEGER NumberOfConnections;
        STRING Username[];
        STRING Password[];
        STRING CertificateFileName[];
        STRING PrivateKeyFileName[];
        MqttSettings Instance;
    };

